﻿using System.Web;
using System.Web.Mvc;

namespace Tech_Task_Empire
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
